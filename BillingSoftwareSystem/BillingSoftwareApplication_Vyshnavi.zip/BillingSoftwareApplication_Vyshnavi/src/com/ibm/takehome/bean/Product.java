package com.ibm.takehome.bean;

public class Product {
	private Integer product_id;
	private static Integer product_price;
	private static String product_name;
	private static String product_category;
	
	public Product(int product_id, String product_name, String product_category, int product_price) {
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_category = product_category;
		this.product_price = product_price;
		
	}	
	//Getting the values
	public static String getName() {
		return product_name;
	}
	public Integer getId() {
		return product_id;
	}
	public static Integer getPrice() {
		return product_price;
	}
	public static String getCategory() {
		return product_category;
	}
	
	
	//Setting the values
	public void setName(String product_name) {
		this.product_name = product_name;
	}
	public void setCategory(String product_category) {
		this.product_category = product_category;
	}
	public void setId(Integer product_id) {
		this.product_id = product_id;
	}
	public void setPrice(Integer product_price) {
		this.product_price = product_price;
	}
	
}
