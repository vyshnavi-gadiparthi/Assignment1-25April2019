package com.ibm.takehome.dao;

import com.ibm.takehome.bean.Product;

public interface IProductDao {

	boolean validateQuantity(Integer product_quantity);

	//boolean validateCode(int product_code);

	Product getProductDetails(String product_code);

}
