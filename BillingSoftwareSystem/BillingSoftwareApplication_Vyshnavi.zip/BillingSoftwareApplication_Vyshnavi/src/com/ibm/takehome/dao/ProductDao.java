package com.ibm.takehome.dao;

import java.util.Map;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.util.CollectionUtil;

public class ProductDao implements IProductDao{
	
	
	CollectionUtil collections = new CollectionUtil();

	public Product getProductDetails(String product_code)
	{
		Map<Integer, Product>  products = CollectionUtil.products;
		
		for(Integer pc : products.keySet())
		{
			if(pc == Integer.parseInt(product_code))
				return products.get(pc);
        }
 
		return null;
	}
	
	
	//Validating product quantity
	@Override
	public boolean validateQuantity(Integer product_quantity) {
		if(product_quantity > 0)
			return true;
		else
			return false;
		
	}

}
