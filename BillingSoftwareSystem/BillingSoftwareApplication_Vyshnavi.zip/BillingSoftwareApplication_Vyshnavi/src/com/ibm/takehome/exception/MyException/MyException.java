package com.ibm.takehome.exception.MyException;

public class MyException {

}
