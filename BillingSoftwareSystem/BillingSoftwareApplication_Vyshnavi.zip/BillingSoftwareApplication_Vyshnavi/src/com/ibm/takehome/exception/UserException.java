package com.ibm.takehome.exception;

public class UserException {

}
