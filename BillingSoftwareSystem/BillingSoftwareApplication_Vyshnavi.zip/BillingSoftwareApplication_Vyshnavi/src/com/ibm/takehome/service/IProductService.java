package com.ibm.takehome.service;

import org.omg.CORBA.UserException;

import com.ibm.takehome.bean.Product;

public interface IProductService {
	
	boolean validateQuantity(Integer product_quantity);

	boolean validateCode(String product_code) ;

	Product getProductDetails(String product_code);

	
}
