package com.ibm.takehome.service;


import com.ibm.takehome.exception.UserException;
import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.IProductDao;
import com.ibm.takehome.dao.ProductDao;

public class ProductService implements IProductService {
	
	//Creating dao class object
	IProductDao dao = new ProductDao();
	
	
	
	public boolean validateCode(String product_code) throws UserException{
		
		if (product_code == null) 
			throw new UserException("Product code cannot be empty");
		
		if(product_code.length() == 4)
		{
		    
		    for (int i = 0; i < product_code.length(); i++)
		    	if ((Character.isDigit(product_code.charAt(i)) == false)) 
					

		    
		   return true;
		}
		return false;
	}
	
	
	public Product getProductDetails(String product_code) 
	{
		Product product = dao.getProductDetails(product_code);
		if(product == null)
			throw new UserException("The Product Code <<"+product_code+">> is not available");
		
		
		return dao.getProductDetails(product_code);
		return product;
	}

	public boolean validateQuantity(Integer product_quantity) throws UserException 
	{
		if(product_quantity <= 0)
			throw new UserException("Product quantity cannot be zero or less");
		
		
		else
			return true;
	}


	


	
	
}
