package com.ibm.takehome.ui;

import java.util.Scanner;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.service.IProductService;
import com.ibm.takehome.service.ProductService;

public class Client {
	private static Integer product_quantity;

	public static void main(String[] args) {
		
		//Creating an object for service class
		IProductService service = new ProductService();
		
		//Creating scanner class for taking input
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Display menu to cashier...");
		int flag = 0;
		
		while (flag == 0) {
			try {
					System.out.println("1. Generate bill by entering product code and quantity \n 2.Exit");
					System.out.println("Enter your choice...");
					int choice = scan.nextInt();
					scan.nextLine();
					
					switch(choice) {
					case 1: 
						System.out.println("Enter the product code: ");
						String product_code = scan.nextLine();
												
						if(service.validateCode(product_code)) {
							System.out.println("Enter the quantity: ");
							int product_quantity = scan.nextInt();
							scan.nextLine();
							if(service.validateQuantity(product_quantity)) {
								Product product = service.getProductDetails(product_code);
								System.out.println("Product details are : ");
								System.out.println("Product Name : " +Product.getName());
								System.out.println("Product Category : " +Product.getCategory());
								System.out.println("Product Price : " +Product.getPrice());
								System.out.println("Product Quantity : " +product_quantity);
								System.out.println("Line total : " + Product.getPrice() * product_quantity);
							}
						}else{
							System.out.println("Product code doesnot exists");
						}
						break;
						
					case 2:
						flag = 1;
					}
		}catch(Exception ie)
		{
			System.out.println("Please enter correct input" +ie);
			
		}
	}
}
}
